import pyxel
from GameObject import GameObject

class LemmingBlocker(GameObject):
    
    def __init__(self,tablero,startPosition,startDirection):
        super().__init__()
        self.position = startPosition
        self.direction = startDirection
        self.__tablero = tablero
        self.finish = False

    def update(self,game_speed):
        self.__tablero.setBlock(self.__tablero.getCoord(self.position),20 + int(pyxel.frame_count // (8/game_speed) % 4))
    
    def freeLemming(self):
        """Libera al lemming volviendo a su estado normal"""
        if self.direction != 0:
            self.__tablero.setBlock(self.__tablero.getCoord(self.position),0)
            self.finish = True

    def draw_lemming(self,game_speed):
        pass
