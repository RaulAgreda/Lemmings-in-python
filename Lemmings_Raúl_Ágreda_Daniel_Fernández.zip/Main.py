import pyxel
from GameManager import GameMain
from Vector2 import Vector2
from UI_Button import UI_Text_Button
from UI_Button import UI_Icon_Switch
from SoundSystem import Music
from NormalLemming import NormalLemming
from Tablero import Tablero
import random

class App:
    def __init__(self):
        self.lemmingsRain = []
        self.tablero = Tablero((
        (0, 0, 0, 1),(0, 0, 0, 1),(0, 0, 0, 1),
        (0, 0, 0, 1),(0, 0, 0, 1),(0, 0, 0, 1),
        (0, 0, 0, 1),(0, 1, 0, 1),(0, 1, 0, 1),
        (0, 1, 0, 1),(0, 1, 0, 1),(0, 0, 0, 1),
        (0, 0, 0, 1),(0, 0, 0, 1),(0, 0, 0, 1),
        (0, 0, 0, 1),(0, 0, 0, 1),(0, 0, 0, 1)),
        self.lemmingsRain,8,Vector2(56,40))
        
        WIDTH = 256
        HEIGHT = 256
        CAPTION = "Lemmings by Raúl Ágreda and Daniel Fernández"

        """app_state:
        0: pantalla de inicio,
        1: game
        2: abrir menú con los controles del juego y tal
        3: Game Over """
        self.app_state = 0

        pyxel.init(WIDTH, HEIGHT, caption = CAPTION,fps = 60)

        #Load images
        pyxel.load("assets/my_resource.pyxres")

        self.game = GameMain()
        self.music = Music()

        # Botones
        self.startButton = UI_Text_Button(Vector2(128,100),"START",(3,10,12))
        self.resumeButton = UI_Text_Button(Vector2(128,80),"RESUME",(7,10,3))
        self.restartLevelButton = UI_Text_Button(Vector2(128,100),"RESTART LEVEL (R)",(7,10,8))
        self.exitButton = UI_Text_Button(Vector2(128,180),"EXIT GAME",(8,10,2))

        self.toggleMusicButton = UI_Icon_Switch(Vector2(120,120),(12,13))

        self.exitTimer = 0
        self.stop_level_music = False

        pyxel.mouse(True)

        pyxel.run(self.update, self.draw)

    @property 
    def mousePos(self):
        return Vector2(pyxel.mouse_x,pyxel.mouse_y)

    def update(self):
        # Menú de inicio
        if self.app_state == 0:
            if pyxel.frame_count % random.randint(2,120) == 0:
                self.spawnRandomLemming()
            self.updateLemmingsRain()

            # Cierra el juego
            if self.exitButton.pressedUp():
                self.app_state = 3
                self.exitTimer = pyxel.frame_count

            if self.startButton.pressedUp():
                self.lemmingsRain.clear()     
                self.app_state = 1
                self.music.playMusic()

        # Jugando
        elif self.app_state == 1:     
                           
            self.game.update() 

            # Abrir menú con la M o la P
            if self.game.gameState == 0 and (pyxel.btnp(pyxel.KEY_M) or pyxel.btnp(pyxel.KEY_P)):
                self.app_state = 2

            # Si la música está activada
            if self.toggleMusicButton.on:
                # Apagar música al final del nivel
                if self.game.gameState == 1:
                    self.music.stopMusic()
                    self.stop_level_music = True
                # Encender música al inicio del nivel
                if self.stop_level_music and self.game.gameState == 0:
                    self.music.playMusic()
                    self.stop_level_music = False
        
        # Menú del juego
        elif self.app_state == 2:

            # Vuelve al juego
            if self.resumeButton.pressedUp() or pyxel.btnp(pyxel.KEY_M) or pyxel.btnp(pyxel.KEY_P):
                self.app_state = 1

            # Reincia el nivel    
            if self.restartLevelButton.pressedUp() or pyxel.btnp(pyxel.KEY_R):
                self.app_state = 1
                self.game.start(self.game.level.id)

            # Cierra el juego
            if self.exitButton.pressedUp():
                self.app_state = 3
                self.exitTimer = pyxel.frame_count

            # Enciende y apaga la música
            if self.toggleMusicButton.onChangeEvent():
                self.music.playMusic() if self.toggleMusicButton.on else self.music.stopMusic()
        
    def draw(self):
        pyxel.cls(0)
        
        if self.app_state == 0:    
            # self.tablero.draw()
            self.drawLemmingsRain()            
            self.drawText(Vector2(128,52),"LEMMINGS")
            self.drawText(Vector2(128,68),"BY RAUL AGREDA AND DANIEL FERNANDEZ")
            self.startButton.draw()
            self.exitButton.draw()

        elif self.app_state == 1:
            self.game.draw()

        elif self.app_state == 2:
            self.drawText(Vector2(128,40),"GAME PAUSED",2)
            self.drawText(Vector2(128,60),"Debes salvar al menos a "+str(self.game.level.lemmingsNeeded())+" lemmings",12)
            self.resumeButton.draw()
            self.restartLevelButton.draw()
            self.exitButton.draw()
            self.toggleMusicButton.draw()
        elif self.app_state == 3:
            if pyxel.frame_count - self.exitTimer < 3*60:
                self.drawText(Vector2(128,128),"GAME OVER",7)
            else:
                pyxel.quit()

    # region Pequeño detalle por rellenar xD
    def spawnRandomLemming(self):
        self.lemmingsRain.append(NormalLemming(self.tablero))
        self.lemmingsRain[-1].position = Vector2(random.randint(0,256),-16)
        self.lemmingsRain[-1].direction = -1 if random.randint(0,1) == 0 else 1

    def updateLemmingsRain(self):
            for lemming in self.lemmingsRain:
                if pyxel.frame_count % 2 == 0:
                    lemming.update(1)
                if not lemming.alive:
                    lemming.lemmingState = 0
                    lemming.alive = True
                if pyxel.btnp(pyxel.MOUSE_LEFT_BUTTON):
                    if self.mousePos.distance(lemming.position) < 20:
                        lemming.lemmingState = 2
                if lemming.position.y > 270:
                    self.lemmingsRain.remove(lemming)
                    del(lemming)

    def drawLemmingsRain(self):
        for lemming in self.lemmingsRain:
            lemming.draw_lemming(1)
            if lemming.lemmingState == 1 and self.mousePos.distance(lemming.position) < 20:
                pyxel.blt(*(self.mousePos + (-8,-16)).asTuple(),1,0,16,16,16,0)
    #endregion

    def drawText(self,position:Vector2,text,color = 7):
        """Dibuja un texto pero con sus coordenadas centradas"""
        pyxel.text(position.x-(4*len(text)//2),position.y - 4,text,color)


App()